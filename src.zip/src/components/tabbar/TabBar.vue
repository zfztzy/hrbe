<template>
  <div id="tab-bar">
    <slot></slot>
  </div>
</template>

<script>
export default {
    name:'TabBar',
    
}
</script>

<style>
#tab-bar{
    display: flex;
    background-color: #fdfdfd;
}

</style>