<template>
    <a-layout-footer style="text-align: center">
        created by cfliangf@isoftstone.com
    </a-layout-footer>
</template>

<script>
export default {
    name:'Foot'
}
</script>

<style>
</style>