<template>
    <div class="footer" id="bot">
        <h3 style="botTitle">create by cfliangf@isoftstone.com</h3>
    </div>
</template>

<script>
export default {
    name:'Foot'
}
</script>

<style>
.footer {
    padding: 15px;
    text-align: center;
    background: #ddd;
    height: 55px;
}

.botTitle{
  display: flex;
  justify-content: center;
  align-items: center;
  height: 130px;
  position: relative;
}
</style>