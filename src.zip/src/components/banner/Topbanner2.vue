<template>
  <div id='top' class="top2">
    <h1 align="center" class="topTitle">海思管理系统</h1>
  </div>
</template>

<script>
export default {

}
</script>

<style>

.top2 {
  height: 130px;
  background-color: lightskyblue;
}

.topTitle {   
  display: flex;
  justify-content: center;
  align-items: center;
  height: 130px;
  position: relative;
  color: white;
}
</style>