<template>
  <div class="clockIn">
    <Coding/>
  </div>
</template>

<script>
import Coding from '../../components/Coding'
export default {
  components: {Coding  },
  name: 'ClockIn',
}

</script>


<style>

</style>