<template>
  <div class="qa">
      <Coding/>
  </div>
</template>

<script>
import Coding from '../../components/Coding'
// @ is an alias to /src



export default {
  components: { Coding },
  name: 'Qa',
}

</script>
