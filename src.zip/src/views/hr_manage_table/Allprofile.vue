<template>
  <div class="allprofile">
    <br><br><br><br>
    <Homebanner/>
  </div>
</template>

<script>
// @ is an alias to /src
import Homebanner from '../../components/banner/Homebanner'



export default {
  name: 'allprofile',
  components: {
    Homebanner,
  }
}

</script>


