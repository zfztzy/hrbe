<template>
  <div class="profile">
    <Navbar>
      <a v-for='(i) in links' :key="i.msg" @click ='profileDetail(i.type)' :class="{right:i.isRight}">{{i.msg}}</a>
      <a @click="newInfo" :class="{barright:true}">新增</a>
      <a @click="batchInput" :class="{barright:true}">批量导入</a>
      <a @click="batchOutput" :class="{barright:true}">批量导出</a>
    </Navbar>
    <Navbar topStyle="position: sticky; top:49px; z-index: 3;" pagestyle='background-color: white;' v-if="isShow">
      <a v-for='(i) in filter' :key="i.title"  style="width:300px"><a-input :placeholder="i.title" v-model="i.vModel" type="text"/></a>
      <a @click="updateFilter" :class="{barright:true}">搜索</a>
      <a @click="resetFilter" :class="{barright:true}">清除</a>
    </Navbar>
    <router-view :BatchNum="BatchNum" :newSwitch="newSwitch" :filterData='filterData'/>
  </div>
</template>

<script>
import Navbar from '../../components/Navbar.vue'
// @ is an alias to /src



export default {
  components: { Navbar },
  name: 'Profile',
  data(){
    return{
      links:[
            {type:'applicant', msg: '候选人管理', },
            {type:'recruitment', msg: '招聘需求', },
            {type:'pojectStatus', msg: '项目满足度', },
            {type:'projectInfo', msg: '项目信息', },
      ],
      filter:[
        {vModel: undefined, title: '招聘顾问'},
        {vModel: undefined, title: '候选人推荐时间'},
        {vModel: undefined, title: '关联需求'},
        {vModel: undefined, title: '简历状态'},
        {vModel: undefined, title: '地域'},
        {vModel: undefined, title: '岗位'},
      ],
      newSwitch: 0,
      BatchNum: 0,
      isShow: false,
      filterData: {}
    }
  },    
  methods:{
    profileDetail(type){
        this.$router.push({path:'/hrManageTable/' + type})
    },
    refresh(){
      window.scrollTo(0,0);
      this.switchTable()
    },
    batchInput () {
      this.BatchNum += 1
    },
    batchOutput () {
      this.BatchNum -= 1
    },
    newInfo() {
      this.newSwitch += 1
    },
    switchTable () {
      if (this.$route.name==='Applicant') {
        this.isShow = true
      } else {
        this.isShow = false
      }
    },
    resetFilter () {
      this.filter = [
        {vModel: undefined, title: '招聘顾问'},
        {vModel: undefined, title: '候选人推荐时间'},
        {vModel: undefined, title: '关联需求'},
        {vModel: undefined, title: '简历状态'},
        {vModel: undefined, title: '地域'},
        {vModel: undefined, title: '岗位'},
      ]
      this.filterData = {
        recommender: this.filter[0].vModel,
        recommend_time: this.filter[1].vModel,
        related: this.filter[2].vModel,
        resume_status: this.filter[3].vModel,
        region: this.filter[4].vModel,
        job: this.filter[5].vModel
      }
    },
    updateFilter () {
      this.filterData = {
        recommender__icontains: this.filter[0].vModel,
        recommend_time__icontains: this.filter[1].vModel,
        related__icontains: this.filter[2].vModel,
        resume_status__icontains: this.filter[3].vModel,
        region__icontains: this.filter[4].vModel,
        job__icontains: this.filter[5].vModel
      }
      console.log(this.filterData);
    },
    log (a) {
      console.log(a);
    }
  },
  watch:{
    '$route': 'refresh'
  },
  mounted () {
    this.switchTable()
  }
}

</script>
