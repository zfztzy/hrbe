<template>
  <div class="difficulty">
    <Coding/>
  </div>
</template>

<script>
import Coding from '../../components/Coding'

// @ is an alias to /src



export default {
  components: { Coding },
  name: 'Difficulty',
}

</script>
