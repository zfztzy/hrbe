<template>
  <div>
    <div v-show="isBatchControl || isBatchControl2" @click="close" class="maskLayer"></div>
    <batch-input batchType='ProjectInfo' v-show="isBatchControl" @close='close'  class="newApplicant"></batch-input>
    <batch-output batchType='ProjectInfo' v-show="isBatchControl2"  @close='close' class="newApplicant"></batch-output>
    <a-table :columns="columns" :data-source="data" bordered :pagination="{ pageSize: 15 }"  :scroll="{ x: 1500, y: 550 }">
      <div
        slot="filterDropdown"
        slot-scope="{ setSelectedKeys, selectedKeys, confirm, clearFilters, column }"
        style="padding: 8px"
      >
        <a-input
          v-ant-ref="c => (searchInput = c)"
          :placeholder="`Search ${column.dataIndex}`"
          :value="selectedKeys[0]"
          style="width: 188px; margin-bottom: 8px; display: block;"
          @change="e => setSelectedKeys(e.target.value ? [e.target.value] : [])"
          @pressEnter="() => handleSearch(selectedKeys, confirm, column.dataIndex)"
        />
        <a-button
          type="primary"
          icon="search"
          size="small"
          style="width: 90px; margin-right: 8px"
          @click="() => handleSearch(selectedKeys, confirm, column.dataIndex)"
        >
          Search
        </a-button>
        <a-button size="small" style="width: 90px" @click="() => handleReset(clearFilters)">
          Reset
        </a-button>
      </div>
      <a-icon
        slot="filterIcon"
        slot-scope="filtered"
        type="search"
        :style="{ color: filtered ? '#108ee9' : undefined }"
      />
      <template slot="customRender" slot-scope="text, record, index, column">
        <span v-if="searchText && searchedColumn === column.dataIndex">
          <template
            v-for="(fragment, i) in text
              .toString()
              .split(new RegExp(`(?<=${searchText})|(?=${searchText})`, 'i'))"
          >
            <mark
              v-if="fragment.toLowerCase() === searchText.toLowerCase()"
              :key="i"
              class="highlight"
              >{{ fragment }}</mark
            >
            <template v-else>{{ fragment }}</template>
          </template>
        </span>
        <template v-else>
          {{ text }}
        </template>
      </template>
      <template
        v-for="col in ['key', 'department', 'pdu', 'business', 
        'name', 'region', 'delivery_leader', 'pm', 
        'qa', 'hr', 'hwpm']"
        :slot="col"
        slot-scope="text, record"
      >
        <div :key="col">
          <a-input
            v-if="record.editable"
            style="margin: -5px 0"
            :value="text"
            @change="e => handleChange(e.target.value, record.key, col)"
          />
          <template v-else>
            {{ text }}
          </template>
        </div>
      </template>
      <template slot="operation" slot-scope="text, record">
        <div class="editable-row-operations">
          <span v-if="record.editable">
            <a @click="() => save(record.key)">Save</a>
            <a-popconfirm title="Sure to cancel?" @confirm="() => cancel(record.key)">
              <a>Cancel</a>
            </a-popconfirm>
          </span>
          <span v-else>
            <a :disabled="editingKey !== ''" @click="() => edit(record.key)">Edit</a>
          </span>
        </div>
      </template>
    </a-table>
  </div>
</template>
<script>

import BatchInput from '@/components/batchControl/BatchInput.vue';
import BatchOutput from '@/components/batchControl/BatchOutput.vue';
const columns = [
  {
    title: 'project_id',
    dataIndex: 'key',
    width: 200,
    scopedSlots: { customRender: 'key' },
  },
  {
    title: '部门',
    dataIndex: 'department',
    width: 250,
    scopedSlots: { customRender: 'department' },
  },
  {
    title: 'PDU',
    dataIndex: 'pdu',
    width: 100,
    scopedSlots: { customRender: 'pdu' },
  },
  {
    title: '业务块',
    dataIndex: 'business',
    width: 100,
    scopedSlots: { customRender: 'business' },
  },
  {
    title: '项目名称',
    dataIndex: 'name',
    width: 250,
    scopedSlots: { customRender: 'name' },
  },
  {
    title: '地域',
    dataIndex: 'region',
    width: 100,
    scopedSlots: { customRender: 'region' },
  },
  {
    title: '软通交付主管',
    dataIndex: 'delivery_leader',
    width: 200,
    scopedSlots: {
      customRender: 'delivery_leader' 
    }
  },
  {
    title: '软通PM',
    dataIndex: 'pm',
    width: 200,
    scopedSlots: {
      customRender: 'pm' 
    }
  },
  {
    title: '软通QA',
    dataIndex: 'qa',
    width: 100,
    scopedSlots: { customRender: 'qa' },
  },
  {
    title: '软通HR',
    dataIndex: 'hr',
    width: 200,
    scopedSlots: { customRender: 'hr' },
  },
  {
    title: '华为PM',
    dataIndex: 'hwpm',
    width: 150,
    scopedSlots: { customRender: 'hwpm' },
  },
  {
    title: 'operation',
    dataIndex: 'operation',
    fixed: 'right',
    scopedSlots: { customRender: 'operation' },
    width: 130,
  },
];

const data = [];
import * as request from "../../network/request"
for (let i = 0; i < 100; i++) {
  data.push({
    key: i.toString(),
    name: `Edrward ${i}`,
    age: 32,
    address: `London Park no. ${i}`,
    job: `Ed${i}`
  });
}
export default {
  components: { BatchInput, BatchOutput },
  props: {
    BatchNum: {
      type: Number
    }
  },
  data() {
    this.cacheData = data.map(item => ({ ...item }));
    return {
      data,
      columns,
      editingKey: '',
      isNewApplicant: false,
      userName: '',
      searchText: '',
      searchInput: null,
      searchedColumn: '',
      isBatchControl: false,
      filterData: undefined,
      isBatchControl2: false,
    };
  },
  methods: {
    handleChange(value, key, column) {
      const newData = [...this.data];
      const target = newData.filter(item => key === item.key)[0];
      if (target) {
        target[column] = value;
        this.data = newData;
      }
    },
    edit(key) {
      const newData = [...this.data];
      const target = newData.filter(item => key === item.key)[0];
      this.editingKey = key;
      if (target) {
        target.editable = true;
        this.data = newData;
      }
    },
    save(key) {
      const newData = [...this.data];
      const newCacheData = [...this.cacheData];
      const target = newData.filter(item => key === item.key)[0];
      const targetCache = newCacheData.filter(item => key === item.key)[0];
      if (target && targetCache) {
        delete target.editable;
        this.data = newData;
        Object.assign(targetCache, target);
        this.cacheData = newCacheData;
      }
      this.editingKey = '';
      this.updateProjectInfo(key)
    },
    cancel(key) {
      const newData = [...this.data];
      const target = newData.filter(item => key === item.key)[0];
      this.editingKey = '';
      if (target) {
        Object.assign(target, this.cacheData.filter(item => key === item.key)[0]);
        delete target.editable;
        this.data = newData;
      }
    },
    handleSearch(selectedKeys, confirm, dataIndex) {
      confirm();
      this.searchText = selectedKeys[0];
      this.searchedColumn = dataIndex;
    },
    log () {
      console.log(this.searchedColumn);
      console.log(this.searchInput);
      console.log(this.searchText);
    },
    handleReset(clearFilters) {
      clearFilters();
      this.searchText = '';
    },
    editApplicant () {
      this.isNewApplicant = !this.isNewApplicant
    },
    updateProjectInfo (key) {
      let target = {} 
      for (const i of this.data) {
        if (i.key===key) {
          target = i
        }
      }
      request.request({
      url: this.getBaseUrl() + 'update_project_info/',
      method: 'post',
      data: {data: target}
      }).then(res =>{
        console.log(res);
      }).catch(err =>{
        console.log(err);
      })
    },
    getProjectInfo () {
      request.request({
      url: this.getBaseUrl() + 'get_project_info/',
      method: 'post',
      data: {
        filterData: this.filterData,
        filterRegion: this.$cookies.get("region")
      }
      }).then(res =>{
        let a = res.data.infoList
        this.data.length = 0
        for (let i = 0; i < a.length; i++) {
          console.log(a[i]);
          this.data.push(a[i]);
        }
        this.cacheData = data.map(item => ({ ...item }));
      }).catch(err =>{
        console.log(err);
      })
    },
    close () {
      this.isBatchControl = false
      this.isBatchControl2 = false
    },
  },
  created () {
    this.getProjectInfo()
  },
  watch: {
    BatchNum: {
      handler: function (newValue, oldValue) {
        console.log(newValue)
        console.log(oldValue)
        if (newValue > oldValue){
          this.isBatchControl = true
        }
        if (oldValue > newValue){
          this.isBatchControl2 = true
        }
      }
    },
    cleanNum: {
      handler: function (newValue, oldValue) {
        console.log(newValue)
        console.log(oldValue)
        this.isBatchControl = true
      }
    }
  }
};
</script>
<style scoped>
.editable-row-operations a {
  margin-right: 8px;
}

.newApplicant {
  width: 70%;
  height: 70%;
  position: absolute;
  left: 0;
  top: 0;
  background-color: #fff;
  z-index: 999;
  left: 15%;
  top: 15%;
  border-radius: 2%
}

.newApplicantBut {
    z-index: 100;
}

.maskLayer {
  width: 100%;
  height: 100%;
  position: fixed;
  left: 0;
  top: 0;
  z-index: 998;
  background:rgba(0, 0, 0, 0.4);
  filter:alpha(opacity=60);  /*设置透明度为60%*/
  opacity:0.6;  /*非IE浏览器下设置透明度为60%*/
}
</style>
