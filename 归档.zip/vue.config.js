module.exports = {
	assetsDir: 'static'
}